import Area
import sys

print(sys.path)
print(Area.rectangle(4, 7))
print(Area.circle(2))

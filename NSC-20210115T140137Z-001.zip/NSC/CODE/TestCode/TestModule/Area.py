def rectangle(w, h):
	return w * h
	
def circle(r):
	return 22 / 7 * r * r

import lcdlib
import time

lcd = lcdlib.lcd()
lcd.lcd_display_string("Hello Wolrd dd",1)
lcd.lcd_display_string("This is Project",2)

print("")
print("this it file command")
print("file is name testtext.py")
